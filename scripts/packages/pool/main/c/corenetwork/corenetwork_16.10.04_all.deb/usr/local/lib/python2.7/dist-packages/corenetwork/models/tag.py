"""
Copyright (c) 2016 Maciej Nabozny

This file is part of CloudOver project.

CloudOver is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from django.db import models

class Tag(models.Model):
    name = models.CharField(max_length=64)

    class Meta:
        app_label = 'corenetwork'

    @staticmethod
    def get(name):
        try:
            return Tag.objects.get(name=name)
        except:
            t = Tag(name=name)
            t.save()
            return t

    def __str__(self):
        return self.name