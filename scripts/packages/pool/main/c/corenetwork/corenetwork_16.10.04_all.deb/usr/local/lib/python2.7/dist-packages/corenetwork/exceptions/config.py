class ConfigException(Exception):
    pass

class ConfigSyntaxError(ConfigException):
    '''
    Configuration import problems, like typo or syntax errors
    '''
    pass


class ConfigVariableNotFound(ConfigException):
    '''
    Variable not found in config exception
    '''
    pass