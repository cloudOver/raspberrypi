"""
Copyright (c) 2015 Maciej Nabozny
              2015-2016 Marta Nabozny

This file is part of CoreCluster project.

CloudOver is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import importlib
from corenetwork.utils import config


class DriverInterface(object):
    '''
    This class delivers interface for any driver, which responsible for node, vm or core network setup
    '''
    def __init__(self):
        super(DriverInterface, self).__init__()


    def configure_node(self):
        """
        This method is called at node, by corenode, when it is being configured.
        Use "cc-node configure" to start this action. It should be called only
        after cluster configuration is changed.
        """
        pass

    def startup_node(self):
        """
        This method is called when node is started, by corenode start
        """
        pass

    def shutdown_node(self):
        """
        This method is called at node by corenode, when it is going to shutdown.
        """
        pass


    def configure_core(self):
        """
        This method is called at Core installation by "cc-manage agent", when core shall be configured.
        """
        pass


    def startup_core(self):
        """
        This method is called at Core installation, by "cc-manage agent". It starts all agents and manages
        all startup-related tasks.
        """
        pass


    def shutdown_core(self):
        """
        This method is called when Core goes to shutdown. It is called by "cc-manage agent"
        """
        pass


    def prepare_vm(self, vm_name):
        """
        This method is called by Libvirt hook, when VM is defined in Libvirt
        """
        pass


    def startup_vm(self, vm_name):
        """
        This method is called by Libvirt hook, when VM is is powered on
        """
        pass


    def release_vm(self, vm_name):
        """
        This method is called by Libvirt hook, when VM is powered off
        """
        pass


    def start_network(self, network_name):
        """
        This method is called when new network (exactly lease) is created in libvirt (at node)
        """
        pass


    def stop_network(self, network_name):
        """
        This method is called when new network (exactly lease) is destroyed in libvirt (at node)
        """
        pass


    def info_node(self, action, id=None):
        """
        Manage or get information about nodes
        """
        pass


    def info_vm(self, action, id=None):
        """
        Manage vm objects in cluster
        """
        pass


    def info_task(self, action, id=None):
        """
        Manage tasks
        """
        pass


    def info_agent(self, action, id=None):
        """
        Manage agents
        """
        pass


    def info_subnet(self, action, id=None):
        """
        Manage subnets
        """
        pass


    def info_network_pool(self, action, id=None):
        """
        Manage subnets
        """
        pass


    def info_storage(self, action, id=None):
        """
        Manage storages
        """
        pass


    def info_api(self, action, id=None):
        """
        Manage agents
        """
        pass

    def info_image(self, action, id):
        """
        Manage images at cloud storage
        """
        pass

    @staticmethod
    def get_network_routed_driver():
        driver = importlib.import_module(config.get('network', 'NETWORK_ROUTED_DRIVER'))
        return driver.Driver()


    @staticmethod
    def get_network_isolated_driver():
        driver = importlib.import_module(config.get('network', 'NETWORK_ISOLATED_DRIVER'))
        return driver.Driver()


    @staticmethod
    def get_node_driver():
        driver = importlib.import_module(config.get('network', 'NODE_DRIVER'))
        return driver.Driver()


    @staticmethod
    def get_core_driver():
        driver = importlib.import_module(config.get('network', 'CORE_DRIVER'))
        return driver.Driver()


    @staticmethod
    def get_vm_driver():
        driver = importlib.import_module(config.get('network', 'VM_DRIVER'))
        return driver.Driver()

    @staticmethod
    def get_all_drivers():
        return [DriverInterface.get_network_isolated_driver(),
                DriverInterface.get_network_routed_driver(),
                DriverInterface.get_node_driver(),
                DriverInterface.get_core_driver(),
                DriverInterface.get_vm_driver()]
