"""
Copyright (c) 2016 Maciej Nabozny

This file is part of CloudOver project.

CloudOver is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from django.db import models
from corenetwork.models.tag import Tag

class Message(models.Model):
    message = models.TextField()
    function = models.TextField()
    exception = models.TextField(default='', blank=True, null=True)
    date = models.DateTimeField(auto_now_add=True)
    tags = models.ManyToManyField(Tag)
    installation_id = models.CharField(max_length=60, help_text='System installation id (different for each corenetwork installation)')

    class Meta:
        app_label = 'corenetwork'

    @property
    def tag_list(self):
        return ', '.join([t.name for t in self.tags.all()])

    @property
    def has_exception(self):
        return self.exception is not None and self.exception != ''
