"""
Copyright (c) 2014 Maciej Nabozny
              2015-2016 Marta Nabozny

This file is part of CloudOver project.

CloudOver is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import traceback
import syslog
from corenetwork.utils import config
from corenetwork.models import Tag, Message

def log(msg=None, context=None, tags=None, exception=None, function=None, agent=None, loglevel='debug'):
    try:
        tag_list = []
        if tags is not None:
            for tag in tags:
                tag_list.append(Tag.get(tag))

        if context is not None:
            if context.user is not None:
                t = Tag.get('user:' + context.user.id)
                if t not in tag_list:
                    tag_list.append(t)

                t = Tag.get('user')
                if t not in tag_list:
                    tag_list.append(t)

            if context.node is not None:
                t = Tag.get('node:' + context.node.id)
                if t not in tag_list:
                    tag_list.append(t)

                t = Tag.get('node')
                if t not in tag_list:
                    tag_list.append(t)

            if context.vm is not None:
                t = Tag.get('vm:' + context.vm.id)
                if t not in tag_list:
                    tag_list.append(t)

                t = Tag.get('vm')
                if t not in tag_list:
                    tag_list.append(t)

        if agent is not None:
            t = Tag.get('agent:' + context.vm.id)
            if t not in tag_list:
                tag_list.append(t)

            t = Tag.get('agent')
            if t not in tag_list:
                tag_list.append(t)

        ll = Tag.get(loglevel)
        if not ll in tag_list:
            tag_list.append(ll)

        log = Message()
        log.message = msg

        if exception is not None:
            log.exception = traceback.format_exc()
            
        try:
            log.installation_id = config.get('node', 'INSTALLATION_ID')
        except:
            log.installation_id = config.get('core', 'INSTALLATION_ID')

        if function is None:
            log.function = traceback.extract_stack(limit=5)[-3][2]
        else:
            log.function = function

        log.save()

        for tag in tag_list:
            log.tags.add(tag)
        log.save()
    except:
        syslog.syslog(syslog.LOG_ERR, 'Failed to log. %s' % msg)
