"""
Copyright (c) 2016 Marta Nabozny

This file is part of CloudOver project.

CloudOver is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from django.template import loader, Context
import django.conf
from corecluster.utils.logger import *
from corecluster.utils.exception import CoreException
from logger import log

def render(template_path, context):
    try:
        django.conf.settings.configure({'TEMPLATE_DIRS': (
            '/etc/corecluster/templates/',
            '/etc/corenetwork/drivers/',
        )})
    except:
        pass

    try:
        lv_template = loader.get_template(template_path)
        return lv_template.render(Context(context))
    except Exception as e:
        log(msg="Failed to render template", exception=e, tags=('render', 'error'))
        raise CoreException('template_failed')