"""
Copyright (c) 2015 Maciej Nabozny
              2015 Marta Nabozny

This file is part of CloudOver project.

CloudOver is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import re
import netaddr
import netifaces
import requests
import simplejson
from corenetwork.utils import system, config
from corenetwork.utils.logger import log
from distutils.version import StrictVersion


class NetworkMixin():
    def _get_interface_list(self):
        """
        Get list of interfaces available in system and enabled in config (regexps are accepted)
        """
        interfaces = []
        enabled_interfaces = [iface['iface'] for iface in config.get('network', 'INTERFACES')]
        for iface in netifaces.interfaces():
            for iface_name in enabled_interfaces:
                if re.match(iface_name, iface):
                    interfaces.append(iface)
        return interfaces


    def _get_network_list(self):
        interfaces = self._get_interface_list()
        networks = []

        for iface in interfaces:
            addrs = netifaces.ifaddresses(iface)
            # IPv4 addresses
            if not 2 in addrs:
                continue

            for ip in addrs[2]:
                addr = str(netaddr.IPNetwork('%s/%s' % (ip['addr'], ip['netmask'])).cidr)
                networks.append(addr)
        return networks


    def _get_address_list(self):
        interfaces = self._get_interface_list()
        ips = []

        for iface in interfaces:
            addrs = netifaces.ifaddresses(iface)
            # IPv4 addresses
            if not 2 in addrs:
                continue

            for ip in addrs[2]:
                ips.append(ip['addr'])
        return ips


    def _initialize_iptables(self):
        """
        Add iptables chains for redirections and VNC
        """
        null = open('/dev/null', 'w')

        # Public leases
        system.call('sudo iptables -t nat -N CORE_REDIRECTION_DNAT', shell=True, stderr=null)
        system.call('sudo iptables -t nat -D PREROUTING -j CORE_REDIRECTION_DNAT', shell=True)
        system.call('sudo iptables -t nat -A PREROUTING -j CORE_REDIRECTION_DNAT', shell=True)


        system.call('echo 1 | sudo tee /proc/sys/net/ipv4/conf/all/promote_secondaries', shell=True, stdout=null)
        system.call('echo 1 | sudo tee /proc/sys/net/ipv4/ip_forward', shell=True, stdout=null)

        # VNC
        r = system.call('sudo iptables -t nat -N CORE_VNC_DNAT', shell=True)
        if r == 0:
            system.call('sudo iptables -t nat -A CORE_VNC_DNAT -j RETURN', shell=True)
            system.call('sudo iptables -t nat -A PREROUTING -j CORE_VNC_DNAT', shell=True)

            system.call('sudo iptables -t nat -N CORE_VNC_MASQ', shell=True)
            system.call('sudo iptables -t nat -A CORE_VNC_MASQ -j RETURN', shell=True)
            system.call('sudo iptables -t nat -A POSTROUTING -j CORE_VNC_MASQ', shell=True)

        system.call('echo 1 | sudo tee /proc/sys/net/ipv4/ip_forward', shell=True, stdout=null)

        from corecluster.models.core import VM
        from corecluster.cache.task import Task
        for vm in VM.objects.filter(vnc_enabled=True).exclude(state__in=['closed', 'failed', 'closing']).all():
            t = Task()
            t.type = 'console'
            t.action = 'attach_vnc'
            t.append_to([vm])

        null.close()


    def _cleanup_iptables(self):
        """
        Remove iptables chains
        """
        null = open('/dev/null', 'w')

        # Public leases
        system.call('sudo iptables -t nat -D PREROUTING -j CORE_REDIRECTION_DNAT', shell=True, stderr=null)
        system.call('sudo iptables -t nat -X CORE_REDIRECTION_DNAT', shell=True, stderr=null)

        # VNC
        system.call('sudo iptables -t nat -D PREROUTING -j CORE_VNC_DNAT', shell=True, stderr=null)
        system.call('sudo iptables -t nat -D POSTROUTING -j CORE_VNC_MASQ', shell=True, stderr=null)
        system.call('sudo iptables -t nat -F CORE_VNC_DNAT', shell=True, stderr=null)
        system.call('sudo iptables -t nat -F CORE_VNC_MASQ', shell=True, stderr=null)
        system.call('sudo iptables -t nat -X CORE_VNC_DNAT', shell=True, stderr=null)
        system.call('sudo iptables -t nat -X CORE_VNC_MASQ', shell=True, stderr=null)

        null.close()

    def _check_updates(self, component, id='none', current_version=None):
        '''
        Check for updates for component. If current_version is set, return True when newer version is available.
        '''
        try:
            r = requests.get('http://updates.cloudover.org/' + component + '?id=' + id)

            info = simplejson.JSONDecoder().decode(r.text)
            if current_version is not None:
                return StrictVersion(info['latest']) > StrictVersion(current_version)
            else:
                log(msg='Latest version of CoreCluster is %s' % str(info['latest']), tags=('system', 'info'))
        except:
            pass