MODULE = {
    'configs': {'network': '/etc/corenetwork/config.py'},
}
