"""
Copyright (c) 2015 Maciej Nabozny
              2015 Marta Nabozny

This file is part of CloudOver project.

CloudOver is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import random

from corenetwork.utils import system
from corenetwork.network_mixin import NetworkMixin
from corenetwork.os_mixin import OsMixin
from corenetwork.api_mixin import ApiMixin
from corenetwork.driver_interface import DriverInterface

class Driver(NetworkMixin, OsMixin, ApiMixin, DriverInterface):
    def start_node(self):
        system.call('modprobe vxlan', shell=True)
        super(Driver, self).start_node()


    def start_core(self):
        system.call('modprobe vxlan', shell=True)
        super(Driver, self).start_core()
