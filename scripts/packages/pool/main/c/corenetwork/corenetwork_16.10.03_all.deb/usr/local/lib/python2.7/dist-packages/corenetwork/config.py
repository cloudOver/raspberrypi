# This is default configuration file. Use /etc/corenetwork/config.py to override
# default values in this config. Otherwise use CORENETWORK_CONFIG environment variable
# to use another configuration file.


# Use Bonjour/Avahi to discover Core URL. If yes, CORE_URL value is ignored
USE_AUTODISCOVER = True

# Address of core service (API-CI). May be overriden, when USE_AUTODISCOVER
# is enabled
CORE_URL = "http://localhost:8001/"

# Interfaces, which are used to transit traffic between virtual machines.
# You should specify at lease one. It is possible to use wildcard (*) to select
# many interfaces matching it.
INTERFACES = [
    {'iface':   'eth*',
     'cost':    100},
    {'iface':   'wlan*',
     'cost':    1000},
    {'iface':   'ib*',
     'cost':    100}
]

VXLAN_INTERFACE='eth0'
VXLAN_MULTICAST='239.0.0.1'

# Cloud drivers. Each module should contain function-specific methods in Driver class. Those methods
# are used to configure several cloud functionalities, related to driver name. E.g. configure networking
# at all cloud's services (core+nodes) or execute actions when node is starting
NETWORK_ROUTED_DRIVER = 'network.drivers.network_quagga'
NETWORK_ISOLATED_DRIVER = 'network.drivers.network_vxlan'
CORE_DRIVER = 'network.drivers.core_default'
NODE_DRIVER = 'network.drivers.node_default'
VM_DRIVER = 'network.drivers.vm_default'

QUAGGA_PASSWORD = "RANDOM_QUAGGA_PASSWORD"

# The maximum length of network interface name. Used to generate redirection
# interfaces and vpn tunnels. Don't change if any redirection or vpn is active!
IFACE_NAME_LENGTH = 15

import os
import imp
import sys

if 'CORENETWORK_CONFIG' in os.environ:
    ext_config = imp.load_source(os.environ['CORENETWORK_CONFIG'])
    for variable in dir(ext_config):
        setattr(sys.modules[__name__], variable, getattr(ext_config, variable))
