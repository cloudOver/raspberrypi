MODULE = {
    'models': ['coretalk.models.coretalk'],
    'api': ['coretalk.views.api'],
    'hooks': {},
}
