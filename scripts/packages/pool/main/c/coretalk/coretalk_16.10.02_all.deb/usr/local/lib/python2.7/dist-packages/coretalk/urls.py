"""
Copyright (c) 2014 Maciej Nabozny

This file is part of CoreDav project.

CloudOver is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from django.conf.urls import url

urlpatterns = [
    url(r'^$', 'coretalk.views.cloudinit.functions.get_root'),
    url(r'^latest/?$', 'coretalk.views.cloudinit.functions.get_latest'),
    url(r'^latest/meta-data/?$', 'coretalk.views.cloudinit.functions.get_meta_data'),
    url(r'^latest/meta-data/ami-id$', 'coretalk.views.cloudinit.functions.get_ami_id'),
    url(r'^latest/meta-data/hostname$', 'coretalk.views.cloudinit.functions.get_hostname'),
    url(r'^latest/meta-data/instance-id$', 'coretalk.views.cloudinit.functions.get_instance_id'),
    url(r'^latest/meta-data/instance-type$', 'coretalk.views.cloudinit.functions.get_instance_type'),
    url(r'^latest/meta-data/public-keys/?$', 'coretalk.views.cloudinit.functions.get_public_keys'),
    url(r'^latest/meta-data/public-keys/(?P<id>[a-zA-Z0-9\-]+)/?$', 'coretalk.views.cloudinit.functions.get_public_key_formats'),
    url(r'^latest/meta-data/public-keys/(?P<id>[a-zA-Z0-9\-]+)/openssh-key$', 'coretalk.views.cloudinit.functions.get_public_key'),
    url(r'^latest/user-data/?$', 'coretalk.views.cloudinit.functions.get_user_data'),
    url(r'^\d{2,4}-\d{1,2}-\d{1,2}/?$', 'coretalk.views.cloudinit.functions.get_latest'),
    url(r'^\d{2,4}-\d{1,2}-\d{1,2}/meta-data/?$', 'coretalk.views.cloudinit.functions.get_meta_data'),
    url(r'^\d{2,4}-\d{1,2}-\d{1,2}/meta-data/ami-id$', 'coretalk.views.cloudinit.functions.get_ami_id'),
    url(r'^\d{2,4}-\d{1,2}-\d{1,2}/meta-data/hostname$', 'coretalk.views.cloudinit.functions.get_hostname'),
    url(r'^\d{2,4}-\d{1,2}-\d{1,2}/meta-data/instance-id$', 'coretalk.views.cloudinit.functions.get_instance_id'),
    url(r'^\d{2,4}-\d{1,2}-\d{1,2}/meta-data/instance-type$', 'coretalk.views.cloudinit.functions.get_instance_type'),
    url(r'^\d{2,4}-\d{1,2}-\d{1,2}/meta-data/public-keys/?$', 'coretalk.views.cloudinit.functions.get_public_keys'),
    url(r'^\d{2,4}-\d{1,2}-\d{1,2}/meta-data/public-keys/(?P<id>[a-zA-Z0-9\-]+)/?$', 'coretalk.views.cloudinit.functions.get_public_key_formats'),
    url(r'^\d{2,4}-\d{1,2}-\d{1,2}/meta-data/public-keys/(?P<id>[a-zA-Z0-9\-]+)/openssh-key$', 'coretalk.views.cloudinit.functions.get_public_key'),
    url(r'^\d{2,4}-\d{1,2}-\d{1,2}/user-data/?$', 'coretalk.views.cloudinit.functions.get_user_data'),
]
