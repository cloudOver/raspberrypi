MODULE = {
    'models': ['corevpn.models.vpn'],
    'api': ['corevpn.views.api'],
    'configs': {'vpn': '/etc/corevpn/config.py'},
    'hooks': {},
}
