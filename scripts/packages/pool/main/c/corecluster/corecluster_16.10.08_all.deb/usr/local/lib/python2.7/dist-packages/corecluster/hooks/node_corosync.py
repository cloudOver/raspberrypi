"""
Copyright (c) 2015 Marta Nabozny

This file is part of CoreCluster project.

CloudOver is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from corenetwork.network_mixin import NetworkMixin
from corenetwork.os_mixin import OsMixin
from corenetwork.api_mixin import ApiMixin
from corenetwork.config_mixin import ConfigMixin
from corenetwork.hook_interface import HookInterface
from corecluster.models.core import Node
from corecluster.cache.task import Task
from corenetwork.utils import system
import os
import subprocess

class Hook(NetworkMixin, OsMixin, ApiMixin, ConfigMixin, HookInterface):
    task = None

    def cron(self):
        null = open('/dev/null', 'w')
        print "ID\t\t\t\t\tAddress\t\tPresent"

        if os.path.exists('/usr/sbin/corosync-objctl'):
            cmd = '/usr/sbin/corosync-objctl'
        elif os.path.exists('/usr/sbin/corosync-cmapctl'):
            cmd = '/usr/sbin/corosync-cmapctl'
        else:
            print 'Failed to find corosync command (objctl or cmapctl)'
            return

        for node in Node.objects.all():
            ok = False
            id = None

            r1 = system.call('%s | grep %s' % (cmd, node.address), shell=True, stderr=null, stdout=null)
            if r1 == 0:
                id = subprocess.check_output('%s | grep %s | cut -d . -f 7' % (cmd, node.address), shell=True)[:-1]
                r2 = system.call('%s | grep %s | grep joined' % (cmd, id), shell=True, stderr=null, stdout=null)
                if r2 == 0:
                    print '%s\t%s\tok' % (node.id, node.address)
                    ok = True
                else:
                    print '%s\t%s\texited' % (node.id, node.address)
            else:
                print '%s\t%s\tfailed' % (node.id, node.address)

            if id is not None and not ok and node.in_state('ok'):
                node.set_state('offline')
                node.save()

                print "Canceling all, not active tasks for node %s" % node.id
                for task in Task.get_related(node, ['not active']):
                    task.set_state('canceled')
                    task.save()
            elif id is not None and ok and node.in_states(['offline', 'suspend']):
                node.start()
                node.save()
