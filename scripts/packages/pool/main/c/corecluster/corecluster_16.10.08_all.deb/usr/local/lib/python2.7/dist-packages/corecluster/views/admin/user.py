"""
Copyright (c) 2014 Maciej Nabozny
              2016 Marta Nabozny

This file is part of CloudOver project.

CloudOver is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from django.contrib import admin
from corecluster.views.admin_site import admin_site
from corecluster.models.core.user import User


class UserAdmin(admin.ModelAdmin):
    actions = ['delete_selected', 'deactivate', 'activate']
    readonly_fields = ['id', 'last_task', 'state']
    list_display = ['login', 'name', 'surname', 'email', 'state', 'registration_date', 'total_vms', 'defined_vms', 'running_vms']

    list_filter = ('state', 'group')
    ordering = ('login',)

    def has_add_permission(self, request):
        return False


    def save_model(self, request, obj, form, change):
        obj.set_state(obj.default_state)
        obj.save()


    def activate(self, request, queryset):
        names = []
        for s in queryset.all():
            s.set_state('ok')
            s.save()

            names.append(s.name)
        self.message_user(request, 'User account(s) %s are active.' % ', '.join(names))
    activate.short_description = 'Activate account'


    def remove(self, request, queryset):
        names = []
        for s in queryset.all():
            s.set_state('removed')
            s.save()

            names.append(s.name)
        self.message_user(request, 'User account(s) %s are removed.' % ', '.join(names))
    remove.short_description = 'Remove account'


    def deactivate(self, request, queryset):
        names = []
        for s in queryset.all():
            s.set_state('inactive')
            s.save()

            names.append(s.name)
        self.message_user(request, 'User account(s) %s are inactive.' % ', '.join(names))
    deactivate.short_description = 'Lock account'


admin_site.register(User, UserAdmin)
