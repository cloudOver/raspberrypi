Warning!
If you want to change any Libvirt XML templates, you should be aware. This may
cause vm or image fails.