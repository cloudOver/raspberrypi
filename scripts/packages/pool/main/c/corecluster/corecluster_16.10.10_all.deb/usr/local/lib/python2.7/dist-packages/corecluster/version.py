import imp
v_mod = imp.load_source('v', '/etc/corecluster/version.py')
version = v_mod.version
