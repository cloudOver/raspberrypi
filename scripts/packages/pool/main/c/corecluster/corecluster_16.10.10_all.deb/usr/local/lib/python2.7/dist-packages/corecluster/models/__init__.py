"""
Copyright (c) 2014 Maciej Nabozny
              2015 Marta Nabozny

This file is part of CloudOver project.

CloudOver is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from corecluster.settings import APPS
import importlib
from corenetwork.utils.logger import log

for app_name in APPS:
    app = importlib.import_module(app_name).MODULE
    if 'models' in app:
        for model in app['models']:
            try:
                module = importlib.import_module(model)
            except Exception as e:
                try:
                    log(msg='Failed to load database module %s' % model, exception=e, tags=('error', 'critical'))
                except:
                    print('Failed to load model %s from %s: %s' % (model, app_name, str(e)))
                raise Exception('db_model_not_found')
