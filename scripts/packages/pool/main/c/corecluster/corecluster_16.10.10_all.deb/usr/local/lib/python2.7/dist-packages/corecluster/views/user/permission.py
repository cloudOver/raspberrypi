"""
Copyright (c) 2014 Maciej Nabozny

This file is part of CloudOver project.

CloudOver is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from corecluster.utils import validation as v
from corecluster.utils.decorators import register
from corecluster.models.core.token import Token
from corecluster.models.core import Permission



@register(auth='password')
def get_list(context):
    """
    Get list of available permissions (api functions)
    """
    return [p.to_dict for p in Permission.objects.all()]


@register(auth='password', validate={'token_id': v.is_id(), 'function': v.is_string()})
def attach(context, token_id, function):
    """
    Attach permission to token. If token has no permissions, it enables checking permissions for given token.
    :param token_id: Token id
    :param function: function name (e.g. api/image/get_list) without initial and trailing slash (/)
    """
    token = Token.get(context.user_id, token_id)
    permission = Permission.objects.get(function=function)
    token.permissions.add(permission)
    token.ignore_permissions = False
    token.save()


@register(auth='password', validate={'token_id': v.is_id(), 'function': v.is_string()})
def detach(context, token_id, function):
    """
    Remove permission from token
    :param token_id: Token id
    :param function: function name (e.g. api/image/get_list) without initial and trailing slash (/)
    """
    token = Token.get(context.user_id, token_id)
    permission = token.permissions.get(function=function)
    token.permissions.remove(permission)
    token.ignore_permissions = False
    token.save()
