"""
Copyright (c) 2014 Maciej Nabozny

This file is part of CloudOver project.

CloudOver is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import importlib
from django.conf.urls import url
from corecluster.settings import APPS
from corecluster.utils.decorators import decorated_functions
from corecluster.utils.logger import *
from corenetwork.utils.logger import log


try:
    for app_name in APPS:
        app = importlib.import_module(app_name).MODULE
        if 'ci' in app:
            for module in app['ci']:
                print('Loading API module %s for %s' % (module, app_name))
                importlib.import_module(module)
except Exception as e:
    print('Fatal error: %s' % str(e))
    log(msg="CORE: Cannot load module", tags=('error', 'critical'), exception=e)

global decorated_functionss
urlpatterns = []

for func in decorated_functions:
    urlpatterns.append(url(r'^%s/' % (func.function_name.replace('.', '/')), func))
