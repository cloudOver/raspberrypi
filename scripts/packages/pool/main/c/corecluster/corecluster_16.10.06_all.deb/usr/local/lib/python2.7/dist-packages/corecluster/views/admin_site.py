from django.contrib.admin import AdminSite

class CoreClusterAdminSite(AdminSite):
    site_header = 'CoreCluster administration'
    index_template = 'admin_site/index.html'

admin_site = CoreClusterAdminSite(name='myadmin')