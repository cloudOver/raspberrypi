"""
Copyright (c) 2014 Maciej Nabozny
              2016 Marta Nabozny

This file is part of CloudOver project.

CloudOver is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from django.contrib import admin
from corecluster.views.admin_site import admin_site
from corecluster.models.core.vm import VM


class VMStateFilter(admin.SimpleListFilter):
    title = 'VM state'
    parameter_name = 'state'

    def lookups(self, request, model_admin):
        filters = []
        for k in VM.states:
            filters.append((k, k))
        return filters

    def queryset(self, request, queryset):
        if self.value() != None:
            return queryset.filter(state=self.value())


class VMAdmin(admin.ModelAdmin):
    actions = ['delete', 'erase']
    list_display = ['name', 'owner', 'template_details', 'state', 'start_time', 'stop_time']
    list_filter = (VMStateFilter,)
    readonly_fields = ['id', 'state', 'last_task']
    ordering = ('start_time',)


    def has_add_permission(self, request):
        return False


    def has_edit_permission(self, request):
        return False


    def save_model(self, request, obj, form, change):
        obj.set_state(obj.default_state)
        obj.save()


    def erase(self, request, queryset):
        names = []
        for vm in queryset.all():
            vm.cleanup(True)
        self.message_user(request, 'VM(s) %s are marked to delete.' % ', '.join(names))
    erase.short_description = 'Force remove VM'


    def delete(self, request, queryset):
        names = []
        for vm in queryset.all():
            vm.cleanup(False)
        self.message_user(request, 'VM(s) %s are marked to delete.' % ', '.join(names))
    delete.short_description = 'Gently remove VM'


    def owner(self, obj):
        return obj.user.name + ' ' + obj.user.surname + ' (' + str(obj) + ')'


    def template_details(self, obj):
        return str(obj.template) + ' (' + str(obj.template.cpu) + 'CPU ' + str(obj.template.memory) + 'MB Ram)'


admin_site.register(VM, VMAdmin)
