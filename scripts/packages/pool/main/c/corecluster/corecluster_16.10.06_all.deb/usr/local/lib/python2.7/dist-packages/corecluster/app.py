MODULE = {
    'models': ['corecluster.models.core'],
    'api': [
        'corecluster.views.admin',
        'corecluster.views.api',
        'corecluster.views.user',
    ],
    'ci': [
        'corecluster.views.ci',
    ],
    'configs': {
        'core': '/etc/corecluster/config.py',
        'hardware': '/etc/corecluster/hardware.py',
        'agent': '/etc/corecluster/agent.py',
    },
    'hooks': {
        'agent.vm.create': ['corecluster.hooks.vm'],
        'agent.vm.cleanup_vm': ['corecluster.hooks.vm'],
        'cron.minute': ['corecluster.hooks.node_libvirt'],
        'cron.hourly': ['corecluster.hooks.vm_cleanup_db', 'corecluster.hooks.vm_cleanup_task'],
    },
}
