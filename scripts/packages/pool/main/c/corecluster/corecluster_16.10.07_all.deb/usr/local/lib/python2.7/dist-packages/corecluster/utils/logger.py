"""
Copyright (c) 2014 Maciej Nabozny
              2015-2016 Marta Nabozny

This file is part of CloudOver project.

CloudOver is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from corecluster.utils.encoders import CoreEncoder
from corenetwork.utils import config
import json
import traceback
import syslog as ss

LOG_DEBUG = ss.LOG_DEBUG
LOG_INFO = ss.LOG_INFO
LOG_WARNING = ss.LOG_WARNING
LOG_ALERT = ss.LOG_ALERT
LOG_ERR = ss.LOG_ERR
LOG_CRIT = ss.LOG_CRIT

def format_msg(msg, args, response, exception, function=None):
    f = traceback.extract_stack(limit=5)[-3][2]
    a = ''
    e = ''

    if function != None:
        f = function

    if args != None:
        a = ' (args: ' + json.dumps(args, cls=CoreEncoder, indent=4) + ')'

    if response != None:
        a = a + ' (response: ' + json.dumps(response, cls=CoreEncoder, indent=4) + ')'

    if msg:
        a = a + ': '

    if exception != None:
        e = traceback.format_exc().splitlines()

    r = str(f + a + msg).splitlines()
    r.extend(e)
    return r



def syslog(msg=None, args=None, response=None, exception=None, context=None, agent=None, loglevel=ss.LOG_DEBUG, function=None):
    prefix = config.get('core', 'LOG_PREFIX', 'co_')
    if context and context.user != None:
        ss.openlog(str(prefix + 'user_' + context.user.id))
        for l in format_msg(msg, args, response, exception, function):
            ss.syslog(loglevel, l)

    if context and context.node != None:
        ss.openlog(str(prefix + 'node_' + context.node.address))
        for l in format_msg(msg, args, response, exception, function):
            ss.syslog(loglevel, l)

    if context and context.vm != None:
        ss.openlog(str(prefix + 'vm_' + context.vm.id))
        for l in format_msg(msg, args, response, exception, function):
            ss.syslog(loglevel, l)

    if agent != None:
        ss.openlog(str(prefix + 'agent_' + agent))
        for l in format_msg(msg, args, response, exception, function):
            ss.syslog(loglevel, l)


    ss.openlog(str(prefix + 'common'))
    for l in format_msg(msg, args, response, exception, function):
        ss.syslog(loglevel, l)
