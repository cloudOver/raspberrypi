from corecluster.settings import *
ROOT_URLCONF = 'corecluster.urls_cluster_interface'
WSGI_APPLICATION = 'corecluster.wsgi_cluster_interface.application'