"""
Copyright (c) 2014 Maciej Nabozny
              2015 Marta Nabozny

This file is part of CloudOver project.

CloudOver is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from corecluster.utils.decorators import register
from corecluster.settings import APPS
import importlib

@register(auth='token')
def get_list(context):
    """
    Returns list with names and descriptions of all functions available for user.
    Each list element is a dictionary with fields:
    - name - function name (url)
    - doc - documentation for function
    - params - list of parameters for function
    """
    from corecluster.utils.decorators import function_doc
    api_modules = []
    ci_modules = []
    for app_name in APPS:
        app = importlib.import_module(app_name).MODULE
        if 'api' in app:
            api_modules.extend(app['api'])
        if 'ci' in app:
            ci_modules.extend(app['ci'])

    return {
        'functions': function_doc,
        'api_modules': api_modules,
        'ci_modules': ci_modules,
        }


@register(auth='token')
def list_functions(context):
    '''
    Get list with functions and documentations
    '''
    from corecluster.utils.decorators import function_doc
    return function_doc


@register(auth='token')
def list_api_modules(context):
    '''
    Get list of enabled API modules
    '''
    api_modules = []
    for app_name in APPS:
        app = importlib.import_module(app_name).MODULE
        if 'api' in app:
            api_modules.extend(app['api'])
    return api_modules


@register(auth='token')
def list_ci_modules(context):
    '''
    Get list of enabled CI (cluster interface api) modules
    '''
    ci_modules = []
    for app_name in APPS:
        app = importlib.import_module(app_name).MODULE
        if 'ci' in app:
            ci_modules.extend(app['ci'])
    return ci_modules


@register(auth='token')
def core_version(context):
    '''
    Get version of CoreCluster
    '''
    from corecluster import version
    return version.version
