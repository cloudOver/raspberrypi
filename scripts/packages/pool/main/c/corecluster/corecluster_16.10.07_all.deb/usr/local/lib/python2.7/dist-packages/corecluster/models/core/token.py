"""
Copyright (c) 2014 Maciej Nabozny

This file is part of CloudOver project.

CloudOver is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from django.db import models
from corecluster.models.common_models import CoreModel, UserMixin
import hashlib
import random

class Token(UserMixin, CoreModel):
    name = models.CharField(max_length=256, default='')
    token = models.TextField()
    creation_date = models.DateTimeField(auto_now_add=True)
    valid_to = models.DateTimeField(null=True)
    permissions = models.ManyToManyField('Permission', symmetrical=False, blank=True)
    ignore_permissions = models.BooleanField(default=True)

    def _permissions(self):
        r = []
        for p in self.permissions.all():
            r.append(p.function)
        return r

    def _hash(self):
        seed = hashlib.sha1(str(random.random())).hexdigest()[:10]
        token_hash = hashlib.sha1(seed + self.token).hexdigest()
        return str(self.id) + '-' + 'sha1' + '-' + seed + '-' + token_hash

    serializable = ['id', 'data', 'name', ['token', '_hash'], 'creation_date', 'valid_to', 'ignore_permissions', ['permissions', '_permissions']]
    editable = ['name', 'valid_to']

    def __unicode__(self):
        return self.token

