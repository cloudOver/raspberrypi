"""
Copyright (c) 2014 Maciej Nabozny
              2016 Marta Nabozny

This file is part of CloudOver project.

CloudOver is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from django.contrib import admin
from corecluster.views.admin_site import admin_site
from corecluster.models.core.image import Image
from corecluster.cache.task import Task


class ImageStateFilter(admin.SimpleListFilter):
    title = 'Image state'
    parameter_name = 'state'

    def lookups(self, request, model_admin):
        filters = []
        for k in Image.states:
            filters.append((k, k))
        return filters

    def queryset(self, request, queryset):
        if self.value() != None:
            return queryset.filter(state=self.value())


class ImageTypeFilter(admin.SimpleListFilter):
    title = 'Image type'
    parameter_name = 'type'

    def lookups(self, request, model_admin):
        filters = []
        for k in Image.image_types:
            filters.append((k, k))
        return filters

    def queryset(self, request, queryset):
        if self.value() != None:
            return queryset.filter(image_type=self.value())


class ImageAccessFilter(admin.SimpleListFilter):
    title = 'Image access'
    parameter_name = 'access'

    def lookups(self, request, model_admin):
        filters = []
        for k in Image.object_access:
            filters.append((k, k))
        return filters

    def queryset(self, request, queryset):
        if self.value() != None:
            return queryset.filter(access=self.value())


class ImageAdmin(admin.ModelAdmin):
    actions = ['delete']
    list_display = ['name', 'owner', 'size', 'type', 'state']
    readonly_fields = ['id', 'state', 'last_task']
    list_filter = (ImageStateFilter, ImageTypeFilter, ImageAccessFilter)
    ordering = ('creation_date',)


    def has_add_permission(self, request):
        return False


    def has_edit_permission(self, request):
        return False


    def owner(self, obj):
        return obj.user.name + ' ' + obj.user.surname + ' (' + str(obj) + ')'


    def delete(self, request, queryset):
        names = []
        for image in queryset.all():
            task = Task()
            task.type = 'image'
            task.state = 'not active'
            task.action = 'delete'
            task.ignore_errors = True
            task.append_to([image])

            names.append(image.name)
        self.message_user(request, 'Image(s) %s will be removed.' % ', '.join(names))
    delete.short_description = 'Delete'

admin_site.register(Image, ImageAdmin)
