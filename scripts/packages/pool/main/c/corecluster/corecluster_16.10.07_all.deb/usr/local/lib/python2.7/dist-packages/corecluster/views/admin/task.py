from corecluster.cache.task import Task
from corecluster.cache import Cache
from django.contrib.admin.views.decorators import staff_member_required
from django.shortcuts import HttpResponse
import simplejson

@staff_member_required
def graph(request):
    keys = Cache.hkeys(Task.container)
    tasks = [simplejson.loads(Cache.hget(Task.container, k)) for k in keys]
    resp = HttpResponse(simplejson.dumps(tasks, indent=2))
    resp['Content-type'] = 'application/json'
    return resp